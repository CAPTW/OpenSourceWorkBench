OpenSolver Workbench

This is an unsigned portable build.
It is not an MSI installer.
It has no code signing and is not code-signed.
External solver executables are not bundled.
Verify SHA256SUMS.txt before use.
