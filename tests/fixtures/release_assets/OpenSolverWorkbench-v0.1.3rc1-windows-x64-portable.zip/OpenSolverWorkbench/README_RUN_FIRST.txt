fake portable fixture
